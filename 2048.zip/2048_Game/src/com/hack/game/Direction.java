package com.hack.game;

public enum Direction {

    LEFT, RIGHT, UP, DOWN
}
