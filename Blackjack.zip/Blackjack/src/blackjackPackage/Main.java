// Author: Akshay Kollur
//Imports for utilization of specific library for project
package blackjackPackage;

public class Main {

    public static void main(String[] args) {
        System.out.println("Welcome to Blackjack!\n");
        Game blackjack = new Game();

    }

}
