// Author: Akshay Kollur
//Imports for utilization of specific library for project
package blackjackPackage;

public abstract class Gamer {
    private String name;
    private Hand hand;

    public Gamer() {
        this.name = "";
        this.hand = new Hand();
    }

    public Hand getHand() {
        return this.hand;
    }

    public void setHand(Hand hand) {
        this.hand = hand;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void hit(Deck deck, Deck discard) {
        if (!deck.hasCards()) {
            deck.reloadDeckFromDiscard(discard);
        }
        this.hand.takeCardFromDeck(deck);
        System.out.println(this.name + " gets a card");
        this.printHand();
    }

    public void printHand() {
        System.out.println(this.name + "'s hand: ");
        System.out.println(this.hand + " Value: " + (this.hand).handCount());
    }

    public boolean hasBlackjack() {
        if ((this.getHand()).handCount() == 21) {
            return true;
        } else {
            return false;
        }
    }

}
