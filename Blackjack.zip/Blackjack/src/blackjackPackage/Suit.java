//Author: Akshay Kollur
package blackjackPackage;

public enum Suit {
    //Creation of the four String values of suit types:
    //Hearts, Diamonds, Clubs, and Spades
    SPADE("Spades"), HEART("Hearts"), DIAMOND("Diamonds"), CLUB("Clubs");

    String suitName;

    Suit(String suitName) {
        this.suitName = suitName;
    }

    @Override
    public String toString() {
        return this.suitName;
    }
}
