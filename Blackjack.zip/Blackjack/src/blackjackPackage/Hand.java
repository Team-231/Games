// Author: Akshay Kollur
//Imports for utilization of specific library for project
package blackjackPackage;

import java.util.ArrayList;

public class Hand {
    private ArrayList<Card> hand;

    public Hand() {
        this.hand = new ArrayList<Card>();
    }

    public void takeCardFromDeck(Deck deckOfCards) {
        this.hand.add(deckOfCards.takeCard());
    }

    @Override
    public String toString() {
        String output = "";
        for (Card card : this.hand) {
            output += card + " -- ";
        }
        return output;
    }

    public int handCount() {
        int count = 0;
        int aceNum = 0;
        for (Card card : this.hand) {
            count += card.getValue();
            if (card.getValue() == 11) {
                aceNum += 1;
            }
        }

        if ((count > 21) && (aceNum > 0)) {
            while (aceNum > 0 && count > 21) {
                aceNum--;
                count -= 10;
            }
        }

        return count;
    }

    public void discardHandToDeck(Deck discardDeck) {
        discardDeck.addCards(this.hand);
        this.hand.clear();
    }

    public Card getCard(int index) {
        return this.hand.get(index);
    }
}
