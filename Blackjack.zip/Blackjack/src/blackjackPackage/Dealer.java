// Author: Akshay Kollur
//Imports for utilization of specific library for project
package blackjackPackage;

public class Dealer extends Gamer {
    public Dealer() {
        super.setName("Dealer");
    }

    public void printFirstHand() {
        System.out.println("The dealer's hand: ");
        System.out.println((super.getHand()).getCard(0));
        System.out.println("The second card is face down...");
    }
}
