// Author: Akshay Kollur
//Imports for utilization of specific library for project
package blackjackPackage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Deck {
    private ArrayList<Card> deckOfCards;

    public Deck() {
        this.deckOfCards = new ArrayList<Card>();
    }

    public void addCard(Card card) {
        this.deckOfCards.add(card);
    }

    public int cardsLeft() {
        return this.deckOfCards.size();
    }

    public boolean hasCards() {
        if (this.deckOfCards.size() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public void emptyDeck() {
        this.deckOfCards.clear();
    }

    public void addCards(ArrayList<Card> cards) {
        this.deckOfCards.addAll(cards);
    }

    public void reloadDeckFromDiscard(Deck discard) {
        this.addCards(discard.getCards());
        this.shuffleDeck();
        discard.emptyDeck();
        System.out.println(
                "Ran out of cards, creating new deck from discarded pile & shuffling deck");
    }

    public ArrayList<Card> getCards() {
        return this.deckOfCards;
    }

    @Override
    public String toString() {
        String output = "";
        for (int i = 0; i < this.deckOfCards.size(); i++) {
            output += (this.deckOfCards.get(i) + "\n");
        }
        return output;
    }

    public Deck(boolean makeDeck) {
        this.deckOfCards = new ArrayList<>();
        if (makeDeck) {
            for (Suit theSuit : Suit.values()) {
                for (Rank theRank : Rank.values()) {
                    this.deckOfCards.add(new Card(theSuit, theRank));
                }
            }
        }
    }

    public void shuffleDeck() {
        Collections.shuffle(this.deckOfCards, new Random());
    }

    public Card takeCard() {
        Card takeCard = new Card(this.deckOfCards.get(0));
        this.deckOfCards.remove(0);
        return takeCard;
    }

}
