// Author: Akshay Kollur
//Imports for utilization of specific library for project
package blackjackPackage;

import java.util.Scanner;

public class Game {
    Scanner input = new Scanner(System.in);
    //Creation of instance varibales to store scoring of
    //the blackjack game
    //Privates vars to be instanced
    //The pushes variable holds the number of times the dealer and player
    //hands result in the same number outcome at the end of the program/game
    private Deck deck;
    private Deck discarded;
    private Dealer dealer;
    private Player player;
    private int wins;
    private int losses;
    private int pushes;

    //Creation of the default constructor for the Game object, sets all
    //scores to zero values
    public Game() {
        //Creates a new deck with 52 cards
        this.deck = new Deck(true);
        //Creates new empty deck
        this.discarded = new Deck();
        this.dealer = new Dealer();

        //Creates new people
        this.dealer = new Dealer();
        this.player = new Player();

        //Creates initial scores
        this.wins = 0;
        this.losses = 0;
        this.pushes = 0;

        this.deck.shuffleDeck();
        this.startRound();
    }

    private void startRound() {
        //boolean play = true;
        //while (play) {
        if (this.wins > 0 || this.losses > 0 || this.pushes > 0) {
            System.out.print("\nStarting Next Round: Wins: " + this.wins);
            System.out.print(", Losses: " + this.losses + ", Pushes: ");
            System.out.print(this.pushes + "\n");
            this.dealer.getHand().discardHandToDeck(this.discarded);
            this.player.getHand().discardHandToDeck(this.discarded);

        }

        if (this.deck.cardsLeft() < 4) {
            this.deck.reloadDeckFromDiscard(this.discarded);
        }

        this.dealer.getHand().takeCardFromDeck(this.deck);
        this.dealer.getHand().takeCardFromDeck(this.deck);

        this.player.getHand().takeCardFromDeck(this.deck);
        this.player.getHand().takeCardFromDeck(this.deck);

        this.dealer.printFirstHand();
        this.player.printHand();

        if (this.dealer.hasBlackjack()) {
            this.dealer.printHand();

            if (this.player.hasBlackjack()) {
                System.out.println("You both have Blackjack - Push.");
                this.pushes += 1;
                this.startRound();
            } else {
                System.out.println("Dealer has Blackjack. You lose.");
                this.dealer.printHand();
                this.losses += 1;
                this.startRound();
            }
        }
        if (this.player.hasBlackjack()) {
            System.out.println("You got Blackjack. You win!");
            this.wins += 1;
            this.startRound();
        }
        this.player.makeChoice(this.deck, this.discarded);
        if ((this.player.getHand()).handCount() > 21) {
            System.out.println("You went over 21, you busted.");
            this.losses += 1;
            this.startRound();
        }
        this.dealer.printHand();
        while ((this.dealer.getHand()).handCount() < 17) {
            this.dealer.hit(this.deck, this.discarded);
        }
        if ((this.dealer.getHand()).handCount() > 21) {
            System.out.println("Dealer busts!");
            this.wins += 1;
        } else if ((this.dealer.getHand()).handCount() > (this.player.getHand())
                .handCount()) {
            System.out.println("You lose.");
            this.losses += 1;
        } else if ((this.player.getHand()).handCount() > (this.dealer.getHand())
                .handCount()) {
            System.out.println("You win!");
            this.wins += 1;
        } else {
            System.out.println("Push.");
        }
        //System.out.println(
        //"\nPress q to quit or anything else to continue the game: ");
        //if (!(this.input.next().equals("q"))) {
        this.startRound();
        //} else {
        //play = false;
        //}

    }

    /**
     * Creation of the parameterized constructor for the Game object
     *
     * @param wins
     *            : Wins instance variable is set to inputed wins
     * @param losses
     *            : Losses instance variable is set to inputed losses
     * @param pushes
     *            : Pushes instance variable is set to inputed pushes
     */

    @Override
    public String toString() {
        return "Wins: " + this.wins + ", Losses: " + this.losses + ", Pushes: "
                + this.pushes;
    }

}
