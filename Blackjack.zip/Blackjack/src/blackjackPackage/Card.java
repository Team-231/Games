// Author: Akshay Kollur
//Imports for utilization of specific library for project
package blackjackPackage;

public class Card {
    //Creates a playing card
    //Privates instance vars rank and suit for the Card
    private Rank theRank;
    private Suit theSuit;

    //Creation of a Parameterized Card Constructor, contains
    //a rank and a suit

    public Card(Suit theSuit, Rank theRank) {
        this.theSuit = theSuit;
        this.theRank = theRank;
    }

    public Card(Card card) {
        this.theSuit = card.getSuit();
        this.theRank = card.getRank();
    }

    public int getValue() {
        return this.theRank.rankVal;
    }

    public Suit getSuit() {
        return this.theSuit;
    }

    public Rank getRank() {
        return this.theRank;
    }

    @Override
    public String toString() {
        return "[" + this.theRank + " of " + this.theSuit + "] ("
                + this.getValue() + ")";
    }
}
