// Author: Akshay Kollur
//Imports for utilization of specific library for project
package blackjackPackage;

import java.util.Scanner;

public class Player extends Gamer {

    public Player() {
        super.setName("Player");
    }

    Scanner input = new Scanner(System.in);

    public void makeChoice(Deck deck, Deck discard) {
        int choice = 0;
        boolean getNum = true;
        while (getNum) {
            try {
                System.out.println("Enter 1 to hit or 2 to stand: ");
                choice = this.input.nextInt();
                while ((choice != 1 && choice != 2)) {
                    System.out
                            .println("Invalid: Enter 1 to hit or 2 to stand: ");
                    choice = this.input.nextInt();
                }
                getNum = false;

            } catch (Exception e) {
                System.out.println("Invalid");
                this.input.next();
            }
        }

        if (choice == 1) {
            this.hit(deck, discard);
            if ((this.getHand()).handCount() > 20) {
                return;
            } else {
                this.makeChoice(deck, discard);
            }
        } else {
            System.out.println("You Stand.");
        }
    }

}
